<footer class="footer footer-static footer-dark navbar-border">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
      <span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2018 <a class="text-bold-800 grey darken-2" href="https://facebook.com/RealTumelo"
                                                                                     target="_blank">Tumelo Baloyi </a>, All rights reserved. </span>
        <span class="float-md-right d-block d-md-inline-block d-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i></span>
    </p>
</footer>
<script src="<?php echo site_url('assets/app-assets/vendors/js/vendors.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/vendors/js/charts/raphael-min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/vendors/js/charts/morris.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/vendors/js/extensions/unslider-min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/vendors/js/timeline/horizontal-timeline.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/js/core/app-menu.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/js/core/app.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/js/scripts/customizer.js'); ?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/app-assets/js/scripts/pages/dashboard-ecommerce.js'); ?>" type="text/javascript"></script>

</body>
</html>
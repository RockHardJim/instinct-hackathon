<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar"
      data-open="click" data-menu="vertical-menu" data-col="2-columns">
<!-- fixed-top-->
<nav class="header-navbar navbar-expand-md navbar navbar-with-menu fixed-top navbar-semi-light bg-gradient-x-grey-blue">
    <div class="navbar-wrapper">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                <li class="nav-item">
                    <a class="navbar-brand" href="<?php echo site_url('/') ?>">
                        <h2 class="brand-text">iNSTINCT</h2>
                    </a>
                </li>
                <li class="nav-item d-md-none">
                    <a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="fa fa-ellipsis-v"></i></a>
                </li>
            </ul>
        </div>

        <div class="navbar-container content">
            <div class="collapse navbar-collapse" id="navbar-mobile">
                <ul class="nav navbar-nav mr-auto float-left">
                    <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
                    <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                </ul>
                <ul class="nav navbar-nav float-right">
                    <li class="dropdown dropdown-user nav-item">
                        <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                            <span class="user-name"><?php echo $this->encrypt->decode($admin[0]->name) .' '. $this->encrypt->decode($admin[0]->surname); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?php echo site_url('auth/logout') ?>"><i class="ft-power"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>



<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" navigation-header">
                <span>General</span><i class=" ft-minus" data-toggle="tooltip" data-placement="right" data-original-title="General"></i>
            </li>
            <li class=" nav-item"><a href="<?php echo site_url('user/panel'); ?>"><i class="ft-home"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
            </li>
            <li class=" nav-item"><a href="<?php echo site_url('user/vehicles'); ?>"><i class="icon-speedometer"></i><span class="menu-title" data-i18n="">Vehicles</span></a>
            </li>
            <li class=" nav-item"><a href="<?php echo site_url('user/bountyhunters'); ?>"><i class="icon-user"></i><span class="menu-title" data-i18n="">Security Personel</span></a>
            </li>

            <li class=" navigation-header">
                <span>Apps</span><i class=" ft-minus" data-toggle="tooltip" data-placement="right"
                                    data-original-title="Apps"></i>
            </li>
            <li class=" nav-item"><a href="#"><i class="ft-globe"></i><span class="menu-title" data-i18n="">Dispatch</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="#">Vertical</a>
                        <ul class="menu-content">
                            <li><a class="menu-item" href="../vertical-modern-menu-template">Modern Menu</a>
                            </li>
                            <li><a class="menu-item" href="../vertical-menu-template">Semi Light</a>
                            </li>
                            <li><a class="menu-item" href="../vertical-menu-template-semi-dark">Semi Dark</a>
                            </li>
                            <li><a class="menu-item" href="../vertical-menu-template-nav-dark">Nav Dark</a>
                            </li>
                            <li><a class="menu-item" href="../vertical-menu-template-light">Light</a>
                            </li>
                            <li><a class="menu-item" href="../vertical-overlay-menu-template">Overlay Menu</a>
                            </li>
                        </ul>
                    </li>
                    <li><a class="menu-item" href="#">Bounty</a>
                        <ul class="menu-content">
                            <li><a class="menu-item" href="../horizontal-menu-template">Assign</a>
                            </li>
                            <li><a class="menu-item" href="../horizontal-menu-template-nav">View Stats</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>

        </ul>
    </div>
</div>
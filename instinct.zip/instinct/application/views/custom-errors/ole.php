<body class="vertical-layout vertical-menu 1-column  bg-maintenance-image menu-expanded blank-page blank-page"
      data-open="click" data-menu="vertical-menu" data-col="1-column">
<!-- ////////////////////////////////////////////////////////////////////////////-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <section class="flexbox-container">
                <div class="col-12 d-flex align-items-center justify-content-center">
                    <div class="col-md-4 col-10 box-shadow-2 p-0">
                        <div class="card border-grey border-lighten-3 px-1 py-1 box-shadow-3 m-0">
                            <div class="card-body">
                  <span class="card-title text-center">
                  </span>
                            </div>
                            <div class="card-body text-center">
                                <h3>Noob Alert</h3>
                                <p>I am sorry but i am insanely hard to hack especially to noobs.
                                    <br> Need help??</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>